/**
 * Provides several correlation/distance measures 
 */
package org.mymedialite.correlation;