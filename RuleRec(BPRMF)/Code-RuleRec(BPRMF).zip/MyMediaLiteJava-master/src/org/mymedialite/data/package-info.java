/**
 * Defines MyMediaLite's principal data structures.
 * 
 * These are used for example to store the interaction data that is used to train personalized recommenders.
 */
package org.mymedialite.data;