/**
 * Provides standard data types that are used by MyMediaLite (matrices, vectors, etc)
 */
package org.mymedialite.datatype;