/**
 * Provides functions related to the diversification of recommendation lists.
 */
package org.mymedialite.diversification;