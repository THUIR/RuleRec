/**
 * Defines types of recommender ensembles. 
 */
package org.mymedialite.ensemble;