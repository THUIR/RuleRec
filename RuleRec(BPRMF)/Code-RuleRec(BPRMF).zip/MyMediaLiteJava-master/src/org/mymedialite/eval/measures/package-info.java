/**
 * Provides different evaluation measures. 
 */
package org.mymedialite.eval.measures;