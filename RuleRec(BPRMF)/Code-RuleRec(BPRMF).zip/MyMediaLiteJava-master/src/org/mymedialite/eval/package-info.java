/**
 * Provides contains evaluation routines.
 */
package org.mymedialite.eval;