/**
 * Example applications for item recommenders and rating predictors.
 */
package org.mymedialite.examples;