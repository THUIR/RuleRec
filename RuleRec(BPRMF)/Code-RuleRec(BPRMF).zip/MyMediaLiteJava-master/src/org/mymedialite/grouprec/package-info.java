/**
 * Provides recommenders that make recommendations to groups of users.
 */
package org.mymedialite.grouprec;