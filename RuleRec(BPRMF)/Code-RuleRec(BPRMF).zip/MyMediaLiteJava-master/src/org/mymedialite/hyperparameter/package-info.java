/**
 * Provides classes for automated hyper-parameter search.
 */
package org.mymedialite.hyperparameter;