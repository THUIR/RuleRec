/**
 * Provides I/O routines for KDD Cup 2011 data files. 
 */
package org.mymedialite.io.kddcup2011;