/**
 * Provides item recommenders and some helper classes for item recommendation. 
 */
package org.mymedialite.itemrec;