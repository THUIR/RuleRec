/**
 * Defines interfaces for different classes of recommender, models and similarity providers.
 */
package org.mymedialite;