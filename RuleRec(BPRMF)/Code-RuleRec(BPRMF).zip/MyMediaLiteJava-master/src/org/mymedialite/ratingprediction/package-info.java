/**
 * Provides rating predictors and some helper classes for rating prediction.
 */
package org.mymedialite.ratingprediction;