/**
 * Defines taxonomical data structures.
 * i.e. data structures that help us to describe what kind of a thing something is. 
 */
package org.mymedialite.taxonomy;