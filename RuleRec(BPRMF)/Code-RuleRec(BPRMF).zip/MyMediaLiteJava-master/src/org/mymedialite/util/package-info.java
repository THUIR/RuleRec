/**
 * Provides helper code that did not fit anywhere else. 
 */
package org.mymedialite.util;